"""Realiza a orquestração do jogo e invoca os objetos."""
import pygame

from .objetos.tela import Tela

class Gerenciador:
    def __init__(self) -> None:
        self.tela = Tela()

    def roda_loop(self):
        while True:
            self.tela.renderiza()
