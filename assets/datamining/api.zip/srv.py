"""
Data Mining com Python
05/06/2022

API para deploy de um modelo de data mining.

Adaptado do Blog Minerando Dados:
https://www.youtube.com/watch?v=_dRfScGH7NA
"""
import os
import joblib
import numpy as np

from flask import Flask, request, render_template

app = Flask(__name__, static_url_path="/static")

# colocar o caminho para o modelo
model = joblib.load("..\\modelos\\knn.pkl")


@app.route("/")
def display_gui():
    """Mostra a interface gráfica."""
    return render_template("template.html")


@app.route("/verificar", methods=["POST"])
def verificar():
    """Verifica a classe baseada nos dados."""
    return render_template("template.html", species=predict)


if __name__ == "__main__":
    port = int(os.environ.get('PORT', 5500))
    app.run(host='0.0.0.0', port=port)
